{\rtf1\ansi\ansicpg1252\cocoartf2512
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab560
\pard\pardeftab560\slleading20\partightenfactor0

\f0\fs24 \cf0 temp1.object.n.c[0].exports.a.instance.prodigy.player.appearance._name.lastName=(Math.round(Math.random() * 1000))\
temp1.object.n.c[0].exports.a.instance.prodigy.appearance._name.middleName=(Math.round(Math.random() * 1000))\
}