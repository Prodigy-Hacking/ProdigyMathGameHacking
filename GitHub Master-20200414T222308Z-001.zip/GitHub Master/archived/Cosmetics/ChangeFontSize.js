// This allows you to choose the font size of your text.
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FontSize=
