// Changes chat font and color
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.Font="'Comic Sans MS'"
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#ffffff"
// Other chat colors:
//White 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#FFFFFF"
//Red 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#FF0000"
//Silver 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#C0C0C0"
//Gray 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#808080"
//Black 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#000000"
//Green 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#008000"
//Brown 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#A52A2A"
//Blue 
Phaser.GAMES[0].state.states.Login._gameObj.user.chatText.FillColor="#0000FF"
