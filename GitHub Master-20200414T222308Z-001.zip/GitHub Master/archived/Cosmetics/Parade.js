// Makes a parade of monsters come onto the screen!
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.parade();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.parade()%3Bvoid+0
