// Flips your avatar and name backwards.
Phaser.GAMES[0].state.states.Login._gameObj.user.width=Phaser.GAMES[0].state.states.Login._gameObj.user.width*-1;
Phaser.GAMES[0].state.states.Login._gameObj.user.nameText.gameObject.scale=-1;

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.user.width*%3D-1%3BPhaser.GAMES[0].state.states.Login._gameObj.user.nameText.gameObject.scale%3D-1%3Bvoid+0
