# Will's Cheat Menu

This is a cheat menu, that looks good.

Follow the code of conduct, or I will eat you.

Run `webpack` in this folder to compile it.

Paste `bookmarklet.txt` into a bookmark URL and run the bookmarklet to start the cheat menu.

Made by unexpected william#8124 (ID: 413143886702313472)
