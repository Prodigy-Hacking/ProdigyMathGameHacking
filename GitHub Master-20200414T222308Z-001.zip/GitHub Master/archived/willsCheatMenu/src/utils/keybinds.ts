window.addEventListener("keydown", event => {
	/*
	if (event.code === "KeyL") {
		Phaser.GAMES[0].state.states.Login._gameObj.user.x = Phaser.GAMES[0].input.mousePointer.position.x;
		Phaser.GAMES[0].state.states.Login._gameObj.user.y = Phaser.GAMES[0].input.mousePointer.position.y;
	}
	if (event.code === "Escape") {
		Phaser.GAMES[0].state.states.Login._gameObj.open.menus.map(x => x.close());
	}
	if (!Phaser.GAMES[0].state.states.Login._gameObj.open.menus.length) {
		if (event.code === "KeyE") {
			Phaser.GAMES[0].state.states.Login._gameObj.open.backpack();
		}
		if (event.code === "KeyT") {
			Phaser.GAMES[0].state.states.Login._gameObj.open.chat();
		}
	}
	*/
});
