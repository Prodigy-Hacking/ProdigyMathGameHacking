# Citizen Code of Conduct

## 1. Purpose (This doesn't have anything to do with our hacking standards)

A primary goal of Prodigy Math Game Hacking is to be inclusive to the largest number of contributors, with the most varied and diverse backgrounds possible. As such, we are committed to providing a friendly, safe and welcoming environment for all, regardless of gender, sexual orientation, ability, ethnicity, socioeconomic status, and religion (or lack thereof).

This code of conduct outlines our expectations for all those who participate in our community, as well as the consequences for unacceptable behavior.

We invite all those who participate in Prodigy Math Game Hacking to help us create safe and positive experiences for everyone.

## 2. Open [Source/Culture/Tech] Citizenship

A supplemental goal of this Code of Conduct is to increase open [source/culture/tech] citizenship by encouraging participants to recognize and strengthen the relationships between our actions and their effects on our community.

Communities mirror the societies in which they exist and positive action is essential to counteract the many forms of inequality and abuses of power that exist in society.

If you see someone who is making an extra effort to ensure our community is welcoming, friendly, and encourages all participants to contribute to the fullest extent, we want to know.

# Hacking code of conduct (Please read this)

## Under NO circumstances should ANYBODY be using these hacks to cicumvent privacy of other users, use explicits within the game, phish, or gain access to other accounts without autorization from the original account user.

#### Preferably no plagiarism...

#### You MUST NOT USE **ANY** OF THE HACKS TO ACHIEVE PERSONAL BENEFIT, INCLUDING BUT NOT LIMITED TO...

- Money
- Currencies
- Subscribers/Views on YouTube
- Twitter/Facebook/Instagram followers
- ...

#### FAILING TO FOLLOW OUR TERMS WILL RESULT IN LEGAL ACTION.

# Discord server standards (Can also be found on the Discord server.)

* No NSFW

* Be respectful to other users.

* No racism, sexism, etc.

* No messages with exessive length.

# Thank you for honoring our wishes!
