// Sets game FPS. Found by @BOOM-BOOM-THE-GREAT.
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.SetFPS();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.SetFPS()%3Bvoid+0
