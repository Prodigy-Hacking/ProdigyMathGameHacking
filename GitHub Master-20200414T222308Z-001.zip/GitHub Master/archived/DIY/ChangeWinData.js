// Gives you +1000 on your win data. Found by @aSinnoh.
for (let i = 0; i < 1000; i++) {
 Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.addWin();
}
// UPDATE: an alternate one has been found, located in the "Hacks" folder.

// Bookmarklet:
// javascript:for(var%20i%3D0%3B1E3%3Ei%3Bi%2B%2B)Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.addWin()%3Bvoid+0
