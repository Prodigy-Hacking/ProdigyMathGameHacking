// Always gives you a critical hit. Found by @Magmischief.
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setCritChance(Infinity);

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setCritChance(Infinity)%3Bvoid+0
