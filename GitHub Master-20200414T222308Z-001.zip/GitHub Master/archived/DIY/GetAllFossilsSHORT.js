// Simplified version of getting all fossils. Found by @Magmischief.
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.drDino();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.drDino()%3Bvoid+0
