// Creates snow, created/found by @Magmischief.
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.snow();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.snow()%3Bvoid+0
