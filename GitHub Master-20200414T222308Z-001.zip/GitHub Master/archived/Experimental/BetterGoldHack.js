// Unlike greedIsGood, this changes your gold by any amount, instead of it always capping at 1m. (NOTE: gold completely caps at 1b. Nothing I can do about that.)
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.smallLoan();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.smallLoan()%3Bvoid+0
