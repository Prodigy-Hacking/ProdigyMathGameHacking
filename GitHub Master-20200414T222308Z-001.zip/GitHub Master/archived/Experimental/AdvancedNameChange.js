// brings up the advanced name change, this makes sure you don't break your account by choosing a name that's already taken.
Phaser.GAMES[0].state.states.Login._gameObj.network.open.advancedNameChange();

// bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.network.open.advancedNameChange();
