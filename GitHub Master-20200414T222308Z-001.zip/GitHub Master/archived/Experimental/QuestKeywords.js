// Keywords for quest auto-completion. (Don't paste this into the console. It won't do anything.)
forest
shiverchill
skywatch
bonfire_spire
dyno
lamplight
academy
earthtower
shipwreck_shore
