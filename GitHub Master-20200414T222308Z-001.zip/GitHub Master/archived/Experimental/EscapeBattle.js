// Use this during combat to instantly escape!
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.escapeBattle();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.escapeBattle()%3Bvoid+0
