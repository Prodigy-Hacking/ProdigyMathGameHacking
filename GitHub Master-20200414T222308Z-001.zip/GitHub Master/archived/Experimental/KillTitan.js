// Instantly kills the Titan.
Phaser.GAMES[0].state.states.Login._gameObj.titansNetworkHandler.hitTitan(Infinity);

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.titansNetworkHandler.hitTitan(Infinity)%3Bvoid+0
