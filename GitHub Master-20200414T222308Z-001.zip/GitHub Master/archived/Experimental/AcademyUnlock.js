Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setLevel(15); // Sets level to 15.
Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.unlockAcademy(); // Unlocks the Academy

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setLevel(15)%3BPhaser.GAMES[0].state.states.Login._gameObj.debugQuests.unlockAcademy()%3Bvoid+0
