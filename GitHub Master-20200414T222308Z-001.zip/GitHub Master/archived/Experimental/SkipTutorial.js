Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.completeTutorial(); // Lets you skip that annoying tutorial for new accounts (NOTE: MAKE SURE YOU GIVE YOURSELF A NAME FIRST!! 😄)

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.completeTutorial()%3Bvoid+0
