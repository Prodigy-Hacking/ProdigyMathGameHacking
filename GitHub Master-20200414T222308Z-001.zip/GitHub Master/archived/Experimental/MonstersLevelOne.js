//Sets All Monsters To Level One
Phaser.GAMES[0].state.states.Login._gameObj.battle.constructor.MOD_DEFAULTS.level = 1;
//Bookmarklet
// javascript:(function()%7BPhaser.GAMES[0].state.states.Login._gameObj.battle.constructor.MOD_DEFAULTS.level%20%3D%201%7D)()
