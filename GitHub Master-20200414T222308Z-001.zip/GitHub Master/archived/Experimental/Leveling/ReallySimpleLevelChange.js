Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setLevel(); // Just a level hack that's more simple than the `addStars` function...

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setLevel()%3Bvoid+0
