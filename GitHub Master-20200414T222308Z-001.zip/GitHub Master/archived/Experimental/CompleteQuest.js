// Completes quest requirements. For the keywords, go to https://raw.githubusercontent.com/PatheticMustan/ProdigyMathGameHacking/master/Experimental/QuestKeywords.js
Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.completeQuestRequirements(" ");

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.completeQuestRequirements(%22%20%22)%3Bvoid+0
