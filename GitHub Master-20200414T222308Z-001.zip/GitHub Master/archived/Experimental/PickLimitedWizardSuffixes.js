// Allows you to pick a wizard suffix out of a list Prodigy gives you, rather than just randomly.
Phaser.GAMES[0].state.states.Login._gameObj.network.open.nameChange();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.network.open.nameChange()%3Bvoid+0
