[ProdigyMathGameHackingTypings](README.md) › [Globals](globals.md)

# ProdigyMathGameHackingTypings

# Prodigy Math Game Hacks

# Links

-   **[Wiki](https://github.com/PatheticMustan/ProdigyMathGameHacking/wiki)**
-   **[DIY!](https://github.com/PatheticMustan/ProdigyMathGameHacking/issues/25)**
-   **[Discord](https://discord.gg/9cKMgMv)**
-   **[Instructional Video](https://drive.google.com/file/d/1QZ1659V_8OJvdySRTmKjfJxbI-zukEib/view?usp=sharing)**

## Collaborators

-   [PatheticMustan](https://github.com/PatheticMustan)
-   [Avn1114](https://github.com/Avn1114)
-   [Magmischief](https://github.com/Magmischief)
-   [RubberDuck55](https://github.com/RubberDuck55)

# Announcements

## Let's try and expand our wiki! Feel free to contribute!

**[Click here!](https://github.com/PatheticMustan/ProdigyMathGameHacking/wiki)**

#### Notice: Someone by the name Void-Hacks stole work from this Repo.

This was not a simple code like most things here it was a script that I ([RubberDuck55](https://github.com/RubberDuck55)) worked very hard on. This would not be such a big deal if they contacted us or gave credit. Please do not steal from anyone anywhere. Also please do not spread hate for this person or anyone.

#### Notice: We are NOT trying to ruin Prodigy Math Game.

This may look like we're trying to ruin the game, but we're helping make it better. By finding exploits, we help the developers find that there is an exploit, and the developers fix it, overall helping the game. Anyone who claims that we are 'malicious' or 'ruining the game', are wrong. Please don't spread misinformation.

## We have surpassed 100k views and over 4.5k unique viewers!

Thank all of you for making this happen.

# Hacking Prodigy, the Math Game

I'm making this repository to try to get the developers to change how Prodigy handles player game data. Instead of handling everything server side, a lot of the heavy lifting is done on the player side. The server just manages multiplayer battles, and hosts data, messages, and events.

Basically any changes you make to Phaser.GAMES[0].state.states.Login.\_gameObj.player will save. Be warned, if you mess up the data TOO much, the server gets really confused, and your account is broken forever! Don't do this on your main account. I've already broken three accounts. ;)

# Disclaimer

THESE HACKS MAY OR MAY NOT BREAK YOUR ACCOUNT. DO NOT USE ANY OF THESE HACKS ON YOUR MAIN ACCOUNT, OR YOU MAY RISK YOUR ACCOUNT BECOMING IRREPERABLY BUGGED OUT, PREVENTING YOU FROM PLAYING THE GAME USING THAT ACCOUNT.
You have been warned.

# Usage

Use the command Control+Shift+I to access the console. Paste the code into the console. It's that simple.

You can also use the bookmarklet way by going to https://caiorss.github.io/bookmarklet-maker/ and pasting the code into the big box then by clicking generate you covert the code to a bookmarklet so then go to the output box and copy the converted code and save it as a bookmark and go to prodigy and excute the script by clicking on it. It's that simple.

Any questions? Join our [Discord](https://discord.gg/9cKMgMv)!

Documentation: [Docs](./docs/interfaces/_pixi_d_.pixi.md)
