[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["game.d"](_game_d_.md)

# Module: "game.d"

## Index

### Interfaces

* [Game](../interfaces/_game_d_.game.md)
