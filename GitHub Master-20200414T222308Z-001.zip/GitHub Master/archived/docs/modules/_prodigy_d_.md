[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["prodigy.d"](_prodigy_d_.md)

# Module: "prodigy.d"

## Index

### Interfaces

* [Prodigy](../interfaces/_prodigy_d_.prodigy.md)
