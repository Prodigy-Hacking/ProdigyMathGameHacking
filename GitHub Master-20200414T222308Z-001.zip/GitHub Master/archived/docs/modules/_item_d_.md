[ProdigyMathGameHackingTypings](../README.md) › [Globals](../globals.md) › ["item.d"](_item_d_.md)

# Module: "item.d"

## Index

### Type aliases

* [Item](_item_d_.md#item)

## Type aliases

###  Item

Ƭ **Item**: *[TODO](_util_d_.md#todo)*
