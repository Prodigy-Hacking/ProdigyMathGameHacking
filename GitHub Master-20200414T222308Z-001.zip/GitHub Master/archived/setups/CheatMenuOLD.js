//Please Dont Steal this I can Find you

console=0;

e=await (await fetch("https://api.prodigygame.com/game-api/status")).json();CryptoJS.MD5 = () => ({ toString: () => e.data.prodigyGameFlags.debugPassword });enableDebug('',!0);
//Thanks to will for that

var style = document.createElement('style');
style.innerHTML = '.hide {display: none;}';
document.head.appendChild(style);

var div = document.createElement('div');
var id = document.createAttribute("id");
id.value = 'menu';
div.setAttributeNode(id);

id = document.createAttribute("style");
id.value = 'dysplay:none; position: absolute; z-index: 10; background-color: white;';
div.setAttributeNode(id);
id = document.createAttribute("class");
id.value = 'hide';
div.setAttributeNode(id);
document.body.insertBefore(div,document.getElementById('game-wrapper'));

var div1 = document.createElement('div');
var id = document.createAttribute("id");
id.value = 'submenu';
div1.setAttributeNode(id);

id = document.createAttribute("style");
id.value = 'dysplay:none; position: absolute; left: 8.55%; z-index: 10; background-color: white;';
div1.setAttributeNode(id);
id = document.createAttribute("class");
id.value = 'hide';
div1.setAttributeNode(id);
document.body.insertBefore(div1,document.getElementById('game-wrapper'));

id = document.createElement("p");
id.innerHTML = 'Teleport';
var idea = document.createAttribute('id');
idea.value = 'tele';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Teleports to mouse on keypress';
id.setAttributeNode(idea);
div.appendChild(document.createElement('br'));
div.appendChild(document.createElement('br'));
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Membership';
var idea = document.createAttribute('id');
idea.value = 'member';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Give you a temporary membeship';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Escape Battle';
var idea = document.createAttribute('id');
idea.value = 'escape';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Escapes battle. usually will not complete them, do not use to soon or you can crash prodigy';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Level 100';
var idea = document.createAttribute('id');
idea.value = 'level';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Gives you level 100';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Skip Tutorial';
var idea = document.createAttribute('id');
idea.value = 'tut';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Skips tutorial at begining, make sure you have a name';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Lots of Gold';
var idea = document.createAttribute('id');
idea.value = 'greed';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Give you alot of gold';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = '99 Conjure Cubes';
var idea = document.createAttribute('id');
idea.value = 'conjure';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Gives you 99 conjure cubes giving more will crash the game';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Get All Items';
var idea = document.createAttribute('id');
idea.value = 'items';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Gets you all the items, ALL OF THEM';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Speed Up x10';
var idea = document.createAttribute('id');
idea.value = 'sped';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Makes your game go fast';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Normal Speed';
var idea = document.createAttribute('id');
idea.value = 'notsped';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Reverses the effects of the last one or does nothing';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Insta Kill';
var idea = document.createAttribute('id');
idea.value = 'instakill';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Insta kills all things in your way';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Get all Pets';
var idea = document.createAttribute('id');
idea.value = 'pets';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Gives you all pets (epics too) after hitting just reset the game';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Stats SubMenu';
var idea = document.createAttribute('id');
idea.value = 'sub';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Is a sub menu';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Unlock all Zones';
var idea = document.createAttribute('id');
idea.value = 'zones';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Unlocks all zones';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Max Battle Energy';
var idea = document.createAttribute('id');
idea.value = 'hype';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Hypes up your battle energy';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Get all Furniture';
var idea = document.createAttribute('id');
idea.value = 'furnosh';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Gives you all furniture';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'All Pets Level 100';
var idea = document.createAttribute('id');
idea.value = 'petlevel';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Makes all your pets level 100. use with get all pets to have every single level 100 pet';
id.setAttributeNode(idea);
div.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Monsters Level One';
var idea = document.createAttribute('id');
idea.value = 'mon';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Makes Monsters All Level One';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Invincible';
var idea = document.createAttribute('id');
idea.value = 'tryme';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Makes You Invincible';
id.setAttributeNode(idea);
div1.appendChild(id);

id = document.createElement("p");
id.innerHTML = 'Grade Change';
var idea = document.createAttribute('id');
idea.value = 'grade';
id.setAttributeNode(idea);
var idea = document.createAttribute('title');
idea.value = 'Changes your grade, reload to take affect';
id.setAttributeNode(idea);
div1.appendChild(id);

var e = document.createElement("input");
var a = document.createTextNode("Cheat Menu");
var body = document.getElementsByTagName("body");

e.appendChild(a);

a = document.createAttribute('style');
a.value = 'position: absolute; z-index: 10; width: 50px; height: 50px;';
e.setAttributeNode(a);

a = document.createAttribute('title');
a.value = "Don't cheat that's bad";
e.setAttributeNode(a);

a = document.createAttribute('type');
a.value = 'image';
e.setAttributeNode(a);

a = document.createAttribute('src');
a.value = 'https://play.prodigygame.com/public/assets/images/ed/@2x/ed-sad@2x.png';
e.setAttributeNode(a);

a = document.createAttribute('id');
a.value = 'cheatButton';

e.setAttributeNode(a);

body[0].insertBefore(e, document.getElementById('game-wrapper'));

document.getElementById("cheatButton").addEventListener("click", disp);
document.getElementById('sub').addEventListener("click", disp1);

document.getElementById('tele').addEventListener("click", teleport);
document.getElementById('member' ).addEventListener("click", member);
document.getElementById('escape').addEventListener("click", escape);
document.getElementById('level').addEventListener("click", level);
document.getElementById('tut').addEventListener("click", tut);
document.getElementById('greed').addEventListener("click", greed);
document.getElementById('conjure').addEventListener("click", conjure);
document.getElementById('items').addEventListener("click", item);
document.getElementById('sped').addEventListener("click", sped);
document.getElementById('notsped').addEventListener("click", notsped);
document.getElementById('instakill').addEventListener("click", instakill);
document.getElementById('pets').addEventListener("click", pets);
document.getElementById('zones').addEventListener("click", zones);
document.getElementById('hype').addEventListener("click", hype);
document.getElementById('furnosh').addEventListener("click", furnosh);
document.getElementById('petlevel').addEventListener("click", petlevel);
document.getElementById('mon').addEventListener("click", mon);
document.getElementById('tryme').addEventListener("click", tryme);
document.getElementById('grade').addEventListener("click", grade);

function grade(){
  var g = prompt("What grade would you like to change to? (1-8)");
  Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.grade = g;
}

function tryme(){
  Phaser.GAMES[0].state.states.Login._gameObj.battle.constructor.MOD_DEFAULTS.invincible=true;
}

function mon(){
  Phaser.GAMES[0].state.states.Login._gameObj.battle.constructor.MOD_DEFAULTS.level = 1;
}

function petlevel(){
  for (let i=0; i<Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.kennel.data.length; i++) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.kennel.data[i].level=100;
  };
}

function furnosh(){
  for(var i = 1; i < 148; i++){
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.house.data.items[i] = {A: Array(0), N: 1000};
}
 }

function hype(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setBattleEnergy(Infinity);
}

function zones(){
    Phaser.GAMES[0].state.states.Login._gameObj.classModeController.lockedZones=0;
}

function pets(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.getAllPets();
}

function instakill(){
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.modifiers.damage=Infinity;
}

function sped(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setGameSpeed(10);
}

function notsped(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.setGameSpeed(1);
}

function item(){
a=["outfit", "hat", "boots", "weapon", "spellRelic", "fossil"];
for (u of a) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data[u]=[];
    x = Phaser.GAMES[0].state.states.Boot._gameData[u];
    for (i in x) {
        Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data[u][i] = {"ID": x[i].ID, "N": 1};
    }
}
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.currency=[];
x = Phaser.GAMES[0].state.states.Boot._gameData.currency;
for (i in x) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.currency[i] = {"ID": x[i].ID, "N": 99999999};
}

Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.follow=[];
x = Phaser.GAMES[0].state.states.Boot._gameData.follow;
for (i in x) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.follow[i] = {"ID": x[i].ID};
}
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item=[];
x = Phaser.GAMES[0].state.states.Boot._gameData.item;
for (i in x) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item[i] = {"ID": x[i].ID, "N": 99999999};
}

Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item=[];
x = Phaser.GAMES[0].state.states.Boot._gameData.item;
for (i in x) {
    Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item[i] = {"ID": x[i].ID, "N": 99999999};
}
}

function conjure(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.getCubes(99);
    Phaser.GAMES[0].state.states.Login._gameObj.create.conjureCubeButton();
}

function greed(){
    Phaser.GAMES[0].state.states.Login._gameObj.game.prodigy.debugMisc.getGold(Infinity);
}

function tut(){
    Phaser.GAMES[0].state.states.Login._gameObj.debugQuests.completeTutorial();
}

function level(){
  Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.data.level=100;
}

function member(){
  Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.it=true;
}

function escape(){
  Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.escapeBattle();
}

function teleport(){
window.addEventListener('keydown', (event) => {
Phaser.GAMES[0].state.states.Login._gameObj.user.x=Phaser.GAMES[0].input.mousePointer.position.x;
Phaser.GAMES[0].state.states.Login._gameObj.user.y=Phaser.GAMES[0].input.mousePointer.position.y;
});
}

function disp1(){
    document.getElementById('submenu').classList.toggle("hide");
}

function disp(){
    if(document.getElementById('submenu').classList.value != "hide"){
        document.getElementById('submenu').classList.toggle("hide");
    }
    document.getElementById('menu').classList.toggle("hide");

}
