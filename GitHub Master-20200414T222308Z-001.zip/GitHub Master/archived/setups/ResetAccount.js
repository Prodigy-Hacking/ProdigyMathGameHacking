//This will clear your entire account except for your house.
temp2.player.resetAccount()
