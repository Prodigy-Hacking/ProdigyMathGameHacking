// Opens 1 conjure cube every time you use it.
CryptoJS.MD5=(()=>({toString:()=>gameApiStatusData.prodigyGameFlags.debugPassword})),enableDebug(0,!0);
getCubes()
openCubes()
// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.getCubes(99)%3BPhaser.GAMES[0].state.states.Login._gameObj.create.conjureCubeButton()%3Bvoid+0
