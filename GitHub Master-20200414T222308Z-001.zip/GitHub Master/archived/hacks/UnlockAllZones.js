// Unlocks all zones.
Phaser.GAMES[0].state.states.Login._gameObj.classModeController.lockedZones=0;

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.classModeController.lockedZones%3D0%3Bvoid+0
