Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.tpTowerFloor(); // Teleports you to a Dark tower floor of your choice!

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.tpTowerFloor()%3Bvoid+0
