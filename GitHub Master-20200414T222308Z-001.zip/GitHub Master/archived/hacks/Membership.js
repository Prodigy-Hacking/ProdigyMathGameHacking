CryptoJS.MD5=(()=>({toString:()=>gameApiStatusData.prodigyGameFlags.debugPassword})),enableDebug(0,!0);
setMembership();
