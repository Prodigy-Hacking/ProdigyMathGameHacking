// Gives you unlimited chances at the Wheel of Wonder.
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item.push({"N":Infinity,"ID":130});

// Bookmarklet:
// javascript:Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.backpack.data.item.push(%7BN%3AInfinity%2CID%3A130%7D)%3Bvoid+0
