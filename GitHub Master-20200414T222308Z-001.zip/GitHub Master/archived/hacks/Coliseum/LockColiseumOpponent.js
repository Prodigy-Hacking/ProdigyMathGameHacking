// Use this to counteract UnlockColiseumOpponent.js
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.lockColiseumOpponent();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.lockColiseumOpponent()%3Bvoid+0
