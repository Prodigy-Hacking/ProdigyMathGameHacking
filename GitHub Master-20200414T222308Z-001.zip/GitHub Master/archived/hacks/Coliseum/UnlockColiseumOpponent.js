// Unlock any Coliseum opponent with a number. (1= first opponent, 2= second opponent, etc.)
// You can use LockColiseumOpponent.js to access Coliseum members previous to the ones you unlock.
Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.unlockColiseumOpponent();

// Bookmarklet:
// javascript:Phaser.GAMES[0].state.states.Login._gameObj.debugMisc.unlockColiseumOpponent()%3Bvoid+0
