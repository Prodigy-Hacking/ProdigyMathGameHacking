// Gives the player the maximum amount of bounty points.
CryptoJS.MD5=(()=>({toString:()=>gameApiStatusData.prodigyGameFlags.debugPassword})),enableDebug(0,!0);
getBounty();