// Gives you a new wizard suffix (i.e. Nightcatcher, Quakecaller, Angelbreath, etc.)
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.appearance._name.lastName=(Math.round(Math.random() * 1000));
Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.appearance._name.middleName=(Math.round(Math.random() * 1000));

// Bookmarklet:
// javascript:Phaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.appearance._name.lastName%3DMath.round(1E3*Math.random())%3BPhaser.CanvasPool.pool[0].parent.game.state.states.Boot._metricsManager.gameCompleteDataFactory.gameEventDataBuilder.loggedInPlayer._player.appearance._name.middleName%3DMath.round(1E3*Math.random())%3Bvoid+0
