// Use this during combat, and your energy will fill up to the maximum, allowing you to use all-out attacks amd high energy attacks as much as you want.
//Just make sure to re-paste this script at the beginning of every battle.
CryptoJS.MD5=(()=>({toString:()=>gameApiStatusData.prodigyGameFlags.debugPassword})),enableDebug(0,!0);
setBattleEnergy(10);
