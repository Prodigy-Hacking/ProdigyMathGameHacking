// Gives you all fossils from Dyno Dig Oasis.
CryptoJS.MD5=(()=>({toString:()=>gameApiStatusData.prodigyGameFlags.debugPassword})),enableDebug(0,!0);
drDino();
